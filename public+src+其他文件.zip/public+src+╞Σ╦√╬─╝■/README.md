# qs_map_web

## 目标
1. 主页：HomeMap：展示污染值、监测点、地图
2. 污染统计页：PollutionPlot：展示无坐标的、或统计结果的统计图
3. 新增数据：DataAdding：提交新的污染信息
4. 登录：UserLogin
5. 注册：UserRegister
6. 数据管理：DataManage

# todo
1. 数据管理页尚未实现
2. 所有页面的跳转逻辑复查
3. 登录前后的显示差异
